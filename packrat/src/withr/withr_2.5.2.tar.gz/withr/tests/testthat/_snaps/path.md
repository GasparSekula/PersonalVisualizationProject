# `action` is checked

    'arg' should be one of "prefix", "suffix", "replace"

