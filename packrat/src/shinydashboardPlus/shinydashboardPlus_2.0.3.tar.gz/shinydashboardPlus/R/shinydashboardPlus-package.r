#' shinydashboardPlus
#'
#' @name shinydashboardPlus
#' @docType package
#' @importFrom lifecycle deprecated
"_PACKAGE"