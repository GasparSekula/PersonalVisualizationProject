social_buttons <- 'box(
  title = "Social Buttons",
  width = 12,
  socialButton(
    href = "https://dropbox.com",
    icon = icon("dropbox")
  ),
  socialButton(
    href = "https://github.com",
    icon = icon("github")
  )
)'