label_box <- 'box(
  title = "Closable box, with label", 
  closable = TRUE, 
  width = 12,
  label = boxLabel(1, status = "danger"),
  solidHeader = FALSE, 
  collapsible = TRUE,
  p("Box Content")
)'