library(shiny)

tagList(
  p("Chinese: 中文"),
  helpText("T:\\2_共享区\\11_资料共享\\MO_Task_File")
)
