library(testthat)
library(shiny)

test_check("shiny")
