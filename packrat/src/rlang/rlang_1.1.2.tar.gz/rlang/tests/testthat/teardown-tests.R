
# Until https://github.com/r-lib/testthat/issues/787 is fixed
Sys.setenv("TESTTHAT_PKG" = "")
